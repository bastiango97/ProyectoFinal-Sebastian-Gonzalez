﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Npgsql;

namespace Proyecto_Final_BasesDeDatos {
  public partial class UpdateHosp : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
      Connection con = new Connection();
      con.Connect();
    }

    protected void Button2_Click(object sender, EventArgs e) {
      Response.Redirect("Home.aspx");
    }

    protected void Button1_Click(object sender, EventArgs e) {
      string num_a = TextBox1.Text;
      string key = Session["clave"].ToString();
      Connection con = new Connection();
      con.Connect();
      if (con != null) {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id= postgres; Password = Lolwerasd1; Database = ProyectoFinal");
        conn.Open();
        string query = "update infrastructure set anesthesiologists = "+ num_a + " where id_hosp = " + key;
        NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
        cmd.ExecuteNonQuery();
        Label1.Text = "Update Succesful!";
      }
    }
  }
}