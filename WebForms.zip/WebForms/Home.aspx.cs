﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Npgsql;

namespace Proyecto_Final_BasesDeDatos {
  public partial class Home : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
      Connection con = new Connection();
      con.Connect(); 
      if (con != null) {
        Label1.Text = "Succesful Connection to DataBase";
      }

    }

    protected void Button2_Click(object sender, EventArgs e) {
      Response.Redirect("Search.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e) {
      Session["clave"] = TextBox1.Text;
      Response.Redirect("InfoUpdate2.aspx");
    }

    protected void Button4_Click(object sender, EventArgs e) {
      Session["clave"] = TextBox1.Text;
      Response.Redirect("MonthlyUpdate.aspx");
    }

    protected void Button1_Click(object sender, EventArgs e) {
      Response.Redirect("Register.aspx");
    }

    protected void Button5_Click(object sender, EventArgs e) {
      Session["clave"] = TextBox1.Text;
      Response.Redirect("UpdateHosp.aspx");
    }
  }
}