﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Npgsql;

namespace Proyecto_Final_BasesDeDatos {
  public partial class InfoUpdate : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

    }

    protected void Button1_Click(object sender, EventArgs e) {
      Connection con = new Connection();
      con.Connect();
      string key = Session["clave"].ToString();
      string name = TextBox2.Text;
      string phone = TextBox1.Text;
      if (con != null) {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id= postgres; Password = Lolwerasd1; Database = ProyectoFinal");
        conn.Open();
        string query = "insert into hospitalContact (id_hosp, name_con, phone) values (" + key + ", " +name +", "+ phone + ")";
        NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
        cmd.ExecuteNonQuery();
        Label1.Text = "Contact added";
      }
    }
  }
}