﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Npgsql;

namespace Proyecto_Final_BasesDeDatos {
  public partial class MonthlyUpdate2 : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

    }

        protected void Button1_Click(object sender, EventArgs e) {
          Response.Redirect("Home.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e) {
      string a = DropDownList1.SelectedValue;
      string b = DropDownList2.SelectedValue;
      string c = DropDownList3.SelectedValue; //ox
      string d = DropDownList4.SelectedValue;
      string ee = DropDownList5.SelectedValue;
      string f = DropDownList6.SelectedValue;
      string g = DropDownList7.SelectedValue;
      string h = DropDownList8.SelectedValue;
      string i = DropDownList9.SelectedValue;
      string j = DropDownList10.SelectedValue;
      string k = DropDownList11.SelectedValue;
      string l = DropDownList12.SelectedValue;//shoe covers
      string m = TextBox1.Text;
      string n = TextBox2.Text;
      string o = DropDownList15.SelectedValue;
      string p = TextBox3.Text;
      string q = TextBox4.Text; //pch 
      string moph = DropDownList18.SelectedValue;
      string r = DropDownList16.SelectedValue;
      string s = TextBox5.Text;
      string t = TextBox6.Text;
      string u = DropDownList17.SelectedValue;
      string v = TextBox7.Text;
      string w = TextBox8.Text;
      string x = TextBox9.Text;
      string y = TextBox10.Text;
      string z = TextBox11.Text;
      string aa = TextBox12.Text;
      string bb = DropDownList19.SelectedValue; //status
      string cc = DropDownList20.SelectedValue; //problem
      string idup = "1";//tengo que encontrar una manera de sacar la id_update del registro actual
      Connection con = new Connection();
      con.Connect();
      string id_cont = DropDownList1.SelectedValue;
      if (con != null) {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id= postgres; Password = Lolwerasd1; Database = ProyectoFinal");
        conn.Open();
        string key = Session["clave"].ToString();   //inserta tabla update
        string query = "insert into update1 (id_hosp, succ, status, date_up, id_cont, problem) values (" + key + ", True, '" + bb + "', CURRENT_DATE, " + id_cont + " '" + cc + "'";
        NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
        cmd.ExecuteNonQuery();
        //inserta tabla inventory
        string query2 = "insert into inventory (id_update, oxygen, antipyretics, anesthesic, alcohol, masks, gloves, hats, apron, visors, shoe_covers, covid_tests, ventilators) " +
          "values(" + idup + ", " + c + ", " + d + "," + ee + "," + f + "," + g + "," + h + "," + i + "," + j + "," + k + "," + l + ", " + m + "," + n;
        NpgsqlCommand cmd2 = new NpgsqlCommand(query, conn);
        cmd.ExecuteNonQuery();
        //inserta tabla stats
        string query3 = "insert into stats (id_update, phc_cases, moph_report, num_people_syntoms, positive_cases, int_care_cases, num_deaths_covid, num_deaths_non_covid, patients_recovered)" +
          "values(" + idup + ", " + q + ", '" + moph + "," + v + "," + w + "," + x + "," + y + "," + z + "," + aa;
        NpgsqlCommand cmd3 = new NpgsqlCommand(query, conn);
        cmd.ExecuteNonQuery();

        string query4 = "insert into additionalinfo (id_update, screening_arrival, aw_campaigns, ability_to_test, av_time_results, resources_recieved, num_doctors, num_param_staff)" +
          "values(" + idup + "," + a + ", " + b + ", '" + o + "," + p + "," + r + "," + s + "," + t;
        NpgsqlCommand cmd4 = new NpgsqlCommand(query, conn);
        cmd.ExecuteNonQuery();
        Label1.Text = "Registry succesful!";

      }
    }
  }
}