﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Npgsql;

namespace Proyecto_Final_BasesDeDatos {
  public partial class Search : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
      Connection con = new Connection();
      con.Connect();
      if (con != null) {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id= postgres; Password = Lolwerasd1; Database = ProyectoFinal");
        conn.Open();
        string query = "select id_hosp, name from hospital";
        NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
        DropDownList1.DataSource = cmd.ExecuteReader();
        DropDownList1.DataTextField = "name";
        DropDownList1.DataValueField = "id_hosp";
        DropDownList1.DataBind();

      }
    }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e) {

        }

    protected void Button1_Click(object sender, EventArgs e) {
      String name = DropDownList1.SelectedValue.ToString();
      Label1.Text = name;
    }

        protected void Button2_Click(object sender, EventArgs e) {
          Response.Redirect("Home.aspx");
    }
    }
}