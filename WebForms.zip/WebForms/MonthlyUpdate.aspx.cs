﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Npgsql;

namespace Proyecto_Final_BasesDeDatos {
  public partial class MonthlyUpdate : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
      Connection con = new Connection();
      con.Connect();
      if (con != null) {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id= postgres; Password = Lolwerasd1; Database = ProyectoFinal");
        conn.Open();
        string key = Session["clave"].ToString();
        string query = "select id_cont, phone from hospitalContact where id_hosp = " + key ;
        NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
        DropDownList2.DataSource = cmd.ExecuteReader();
        DropDownList2.DataTextField = "phone";
        DropDownList2.DataValueField = "id_cont";
        DropDownList2.DataBind();
        
      }

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e) {

    }

    protected void Button2_Click(object sender, EventArgs e) {
      String attempt = DropDownList1.SelectedValue;
      if (attempt == "Yes") {
        Response.Redirect("MonthlyUpdate2.aspx");
        Session["id_cont"] = DropDownList1.SelectedValue;
      }
      else {
        Response.Redirect("MonthlyUpdate3.aspx");
        Connection con = new Connection();
        con.Connect();
        string id_cont = DropDownList1.SelectedValue;
        if (con != null) {
          NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id= postgres; Password = Lolwerasd1; Database = ProyectoFinal");
          conn.Open();
          string key = Session["clave"].ToString();
          string query = "insert into update1 (id_hosp, succ, status, date_up, id_cont, problem) values (" + key + ", false, 'Not done', CURRENT_DATE, "+ id_cont+" 'not answered'";
          NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
          cmd.ExecuteNonQuery();
        }

      }
    }

    protected void Button1_Click(object sender, EventArgs e) {
      Response.Redirect("Home.aspx");
    }
  }
}