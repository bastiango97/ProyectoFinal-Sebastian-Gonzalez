﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql; 



namespace Proyecto_Final_BasesDeDatos {
  public class Connection {
    NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id= postgres; Password = Lolwerasd1; Database = ProyectoFinal"); 

    public void Connect() {
      conn.Open();
    }

  }
}