﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Npgsql;

namespace Proyecto_Final_BasesDeDatos {
  public partial class InfoUpdate3 : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
      Connection con = new Connection();
      con.Connect();
      string key = Session["clave"].ToString();
      if (con != null) {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id= postgres; Password = Lolwerasd1; Database = ProyectoFinal");
        conn.Open();
        string query = "select id_cont, name from hospitalContact where id_hosp = " + key;
        NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
        DropDownList1.DataSource = cmd.ExecuteReader();
        DropDownList1.DataTextField = "name";
        DropDownList1.DataValueField = "id_cont";
        DropDownList1.DataBind();
      }
    } 
    protected void Button1_Click(object sender, EventArgs e) {
        Response.Redirect("Home.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e) {
      Connection con = new Connection();
      con.Connect();
      string id = DropDownList1.SelectedValue;
      if (con != null) {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id= postgres; Password = Lolwerasd1; Database = ProyectoFinal");
        conn.Open();
        string query = "delete from hospital contact where id_cont = " + id;
        NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
        cmd.ExecuteNonQuery();
      }
    }

    protected void Button3_Click(object sender, EventArgs e) {
      Connection con = new Connection();
      con.Connect();
      string id = DropDownList1.SelectedValue;
      string phone = TextBox1.Text;
      if (con != null) {
        NpgsqlConnection conn = new NpgsqlConnection("Server = localhost; User Id= postgres; Password = Lolwerasd1; Database = ProyectoFinal");
        conn.Open();
        string query = "update hospitalContact set phone = "+ phone +" where id_cont = " + id;
        NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
        cmd.ExecuteNonQuery();
      }
    }
  }
}