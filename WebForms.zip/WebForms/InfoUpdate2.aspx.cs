﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Proyecto_Final_BasesDeDatos {
  public partial class InfoUpdate2 : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

    }

        protected void Button1_Click(object sender, EventArgs e) {
            Response.Redirect("Home.aspx"); 
    }

    protected void Button3_Click(object sender, EventArgs e) {
      Response.Redirect("InfoUpdate.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e) {
      Response.Redirect("InfoUpdate3.aspx");
    }
  }
}